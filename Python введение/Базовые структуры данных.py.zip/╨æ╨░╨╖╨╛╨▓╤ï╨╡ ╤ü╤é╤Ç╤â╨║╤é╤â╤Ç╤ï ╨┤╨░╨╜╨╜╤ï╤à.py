# 1st program
print(9**0.5*5)

# 2nd program
print(9.99 > 9.98 and 1000 != 1000.1)

# 3rd program
num1, num2 = 1234, 5678
print((num1 // 10) % 100 + (num2 // 10) % 100)

# 4th program
a = 13.42 * 100
b = 42.13 * 100
print(a // 100 == b % 100 or a % 100 == b // 100)
